function remember { 
history | grep "${1}" ; 
}
