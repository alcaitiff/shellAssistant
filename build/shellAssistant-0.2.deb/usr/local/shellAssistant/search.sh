alias search="sudo apt search"
