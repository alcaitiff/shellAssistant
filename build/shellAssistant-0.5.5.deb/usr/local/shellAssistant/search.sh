# Description: APT Search
alias search="sudo apt search"
